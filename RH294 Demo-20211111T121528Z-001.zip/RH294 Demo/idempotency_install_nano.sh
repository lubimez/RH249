#!/bin/bash
PACKAGENAME='nano'


rpm -q ${PACKAGENAME}

if $(rpm -q ${PACKAGENAME}) > /dev/null
  then
    echo Package ${PACKAGENAME} is already installed. Nothing to do.
  else
    sudo yum install -y ${PACKAGENAME}

if `yum check-update ${PACKAGENAME}` > /dev/null
  then
    echo Latest version is installed. Nothing to do.
  else
    sudo yum update ${PACKAGENAME}